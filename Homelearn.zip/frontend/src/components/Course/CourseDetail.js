"use client"

import { useState, useEffect, useMemo } from "react"
import { useParams, Link } from "react-router-dom"
import toast from "react-hot-toast"
import { useAuth } from "../../contexts/AuthContext"
import { api } from "../../utils/api"

// ---- Util: localStorage por usuario/curso para progreso de temas ----
const storageKey = (userId, courseId) => `hl_topic_progress:u${userId || "anon"}:c${courseId}`

const readTopicState = (userId, courseId) => {
  try {
    const raw = localStorage.getItem(storageKey(userId, courseId))
    return raw ? JSON.parse(raw) : {}
  } catch {
    return {}
  }
}

const writeTopicState = (userId, courseId, obj) => {
  try {
    localStorage.setItem(storageKey(userId, courseId), JSON.stringify(obj))
  } catch {}
}

const CourseDetail = () => {
  const { id } = useParams()
  const { user } = useAuth()

  const [course, setCourse] = useState(null)
  const [loading, setLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [errorMsg, setErrorMsg] = useState("")
  const [topicState, setTopicState] = useState({}) // { [levelId]: { [topicIndex]: bool } }

  // ---- Cargar curso ----
  const fetchCourse = async () => {
    setLoading(true)
    setNotFound(false)
    setErrorMsg("")
    try {
      const data = await api.getCourse(id)
      if (!data || typeof data !== "object") {
        setErrorMsg("El servidor devolvió un curso vacío o inválido.")
        setCourse(null)
        setLoading(false)
        return
      }
      setCourse(data)
      // cargar progreso por temas desde localStorage
      setTopicState(readTopicState(user?.id, data.id))

      // auto-enroll si no está inscrito
      if (!data.isEnrolled) {
        try {
          await api.enrollCourse(id)
          const fresh = await api.getCourse(id)
          setCourse(fresh)
          setTopicState(readTopicState(user?.id, fresh.id))
        } catch {
          /* ignore */
        }
      }
    } catch (e) {
      const msg = String(e?.message || "")
      if (msg.includes("404")) {
        setNotFound(true)
      } else {
        setErrorMsg("No se pudo cargar el curso. Intenta nuevamente.")
        toast.error("Error al cargar el curso")
      }
      setCourse(null)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchCourse()
    // no añadimos dependencias para evitar bucles
    // eslint-disable-next-line
  }, [id])

  // ---- Progreso por nivel (usa backend /course/:courseId/level/:levelId/complete) ----
  const getLevelDone = (level) => !!level?.completed

  const toggleLevel = async (courseId, level) => {
    const wasCompleted = !!level.completed
    try {
      await api.completeCourseLevel(courseId, level.id)
      toast.success(wasCompleted ? "Nivel ya estaba marcado" : "¡Nivel completado!")
      // refrescar curso
      fetchCourse()
    } catch {
      toast.error("No se pudo actualizar el nivel")
    }
  }

  // ---- Progreso por tema (solo frontend/localStorage) ----
  const isTopicDone = (levelId, topicIndex) => !!topicState?.[levelId]?.[topicIndex]

  const setTopicDone = (levelId, topicIndex, done) => {
    setTopicState((prev) => {
      const next = {
        ...prev,
        [levelId]: { ...(prev[levelId] || {}), [topicIndex]: !!done },
      }
      if (course?.id) writeTopicState(user?.id, course.id, next)
      return next
    })
  }

  const toggleTopic = (levelId, topicIndex) => {
    const current = isTopicDone(levelId, topicIndex)
    setTopicDone(levelId, topicIndex, !current)
    toast.success(!current ? "¡Tema completado!" : "Tema desmarcado")
  }

  // ---- Métricas ----
  const overallPercent = useMemo(() => {
    const total = course?.levels?.length || 0
    if (!total) return 0
    const done = course.levels.filter((lv) => !!lv.completed).length
    return Math.round((done / total) * 100)
  }, [course])

  const levelTopicsPercent = (level) => {
    const total = level?.topics?.length || 0
    if (!total) return 0
    const done = (level.topics || []).reduce((acc, _t, idx) => acc + (isTopicDone(level.id, idx) ? 1 : 0), 0)
    return Math.round((done / total) * 100)
  }

  // ---- Render ----
  if (loading) {
    return (
      <div className="container text-center" style={{ marginTop: "4rem" }}>
        <div className="spinner"></div>
        <p style={{ marginTop: "1rem" }}>Cargando curso...</p>
      </div>
    )
  }

  if (notFound) {
    return (
      <div className="container text-center" style={{ marginTop: "4rem" }}>
        <h2 className="text-xl font-bold mb-2">Curso no encontrado</h2>
        <p className="text-sm text-gray-400 mb-4">El curso con id {id} no existe o fue eliminado.</p>
        <Link to="/dashboard" className="btn btn-primary">Volver al Dashboard</Link>
      </div>
    )
  }

  if (!course) {
    return (
      <div className="container text-center" style={{ marginTop: "4rem" }}>
        <h2 className="text-xl font-bold mb-2">Hubo un problema</h2>
        <p className="text-sm text-gray-400 mb-4">{errorMsg || "Inténtalo nuevamente."}</p>
        <button className="btn btn-primary" onClick={fetchCourse}>Reintentar</button>
      </div>
    )
  }

  return (
    <div className="container">
      {/* Back Button */}
      <div className="mb-4">
        <Link to="/dashboard" className="btn btn-secondary">← Volver al Dashboard</Link>
      </div>

      {/* Header del Curso */}
      <div className="card mb-6">
        <h1 className="text-2xl font-bold mb-4">{course.title}</h1>

        {/* Progreso general por niveles */}
        <div className="p-4 mb-4" style={{ backgroundColor: "#eff6ff", borderRadius: 8 }}>
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold text-blue-900">📈 Progreso del Curso (por niveles)</h3>
            <span className="text-sm text-blue-700">
              {course.levels?.filter((lv) => !!lv.completed).length}/{course.levels?.length || 0}
            </span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${overallPercent}%` }}></div>
          </div>
          <div className="text-sm text-blue-600">{overallPercent}% del curso completado</div>
        </div>

        <h2 className="text-xl font-bold">Niveles del Curso</h2>
      </div>

      {/* Tarjetas de niveles */}
      {course.levels?.map((level, idx) => (
        <div key={level.id || idx} className="card mb-6">
          {/* Encabezado del nivel */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-xl font-bold">
                {idx + 1} - {level.title || level.level_title || `Nivel ${idx + 1}`}
              </h2>
              <div className="mt-2">
                <div className="text-sm text-gray-700 mb-1">
                  Progreso de temas: {levelTopicsPercent(level)}%
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${levelTopicsPercent(level)}%` }}></div>
                </div>
              </div>
            </div>

            <button
              onClick={() => toggleLevel(course.id, level)}
              className={`btn ${getLevelDone(level) ? "btn-secondary" : "btn-primary"}`}
            >
              {getLevelDone(level) ? "✅ Completado" : "Marcar como Completado"}
            </button>
          </div>

          {/* Secciones del nivel */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Temas con checkbox y botón */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">📚 Temas</h3>
              {level.topics && level.topics.length > 0 ? (
                <ul style={{ listStyle: "none", padding: 0 }}>
                  {level.topics.map((topic, tIdx) => {
                    const done = isTopicDone(level.id, tIdx)
                    return (
                      <li
                        key={tIdx}
                        className="mb-2 p-2 flex items-center justify-between"
                        style={{ backgroundColor: "#0b1220", borderRadius: 8 }}
                      >
                        <span
                          style={{
                            textDecoration: done ? "line-through" : "none",
                            opacity: done ? 0.75 : 1,
                          }}
                        >
                          • {topic}
                        </span>
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={done}
                            onChange={() => toggleTopic(level.id, tIdx)}
                            aria-label={`Marcar tema ${tIdx + 1} del nivel ${idx + 1}`}
                            style={{ width: 18, height: 18 }}
                          />
                          <button
                            onClick={() => toggleTopic(level.id, tIdx)}
                            className={`btn ${done ? "btn-secondary" : "btn-primary"}`}
                            style={{ minWidth: 140 }}
                          >
                            {done ? "✅ Completado" : "Marcar"}
                          </button>
                        </div>
                      </li>
                    )
                  })}
                </ul>
              ) : (
                <p className="text-gray-500">No hay temas definidos</p>
              )}
            </div>

            {/* Objetivos */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">🎯 Objetivos</h3>
              {level.objectives && level.objectives.length > 0 ? (
                <ul style={{ listStyle: "none", padding: 0 }}>
                  {level.objectives.map((obj, oIdx) => (
                    <li key={oIdx} className="mb-2 p-2" style={{ backgroundColor: "#0f3d2e", borderRadius: 8 }}>
                      • {obj}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500">No hay objetivos definidos</p>
              )}
            </div>

            {/* Herramientas */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">🛠️ Herramientas</h3>
              {level.tools && level.tools.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {level.tools.map((tool, i) => (
                    <span key={i} className="text-sm p-2" style={{ backgroundColor: "#3b2f0a", borderRadius: 8 }}>
                      {tool}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">No hay herramientas definidas</p>
              )}
            </div>

            {/* Recursos */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">📖 Recursos</h3>
              {level.resources && level.resources.length > 0 ? (
                <ul style={{ listStyle: "none", padding: 0 }}>
                  {level.resources.map((resource, rIdx) => (
                    <li key={rIdx} className="mb-2 p-2" style={{ backgroundColor: "#3b0a0a", borderRadius: 8 }}>
                      {typeof resource === "string" && resource.startsWith("http") ? (
                        <a href={resource} target="_blank" rel="noopener noreferrer" className="text-blue-400">
                          🔗 {resource}
                        </a>
                      ) : (
                        <span>• {String(resource)}</span>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500">No hay recursos definidos</p>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

export default CourseDetail
