"use client"

import MobileNavigation from "../frontend/src/components/Layout/MobileNavigation"

export default function SyntheticV0PageForDeployment() {
  return <MobileNavigation />
}